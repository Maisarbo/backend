package br.com.maisa;

public class PrimeiraClasse {
    public static void main(String[] args){
        System.out.print("HelloWorld");
    }
}
