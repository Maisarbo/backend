import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Notas notas = new Notas();
        notas.cauc();
        System.out.println(notas.getNota01());
        System.out.println(notas.getNota02());
        System.out.println(notas.getNota03());
        System.out.println(notas.getNota04());
}}