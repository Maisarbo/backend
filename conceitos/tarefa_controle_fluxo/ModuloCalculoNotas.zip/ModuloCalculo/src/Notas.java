import java.util.Scanner;
public class Notas {
    private double nota01;
    private double nota02;
    private double nota03;
    private double nota04;

    public double getNota01() {
        return nota01;
    }

    public void setNota01(double nota01) {
        this.nota01 = nota01;
    }

    public double getNota02() {
        return nota02;
    }

    public void setNota02(double nota02) {
        this.nota02 = nota02;
    }

    public double getNota03() {
        return nota03;
    }

    public void setNota03(double nota03) {
        this.nota03 = nota03;
    }

    public double getNota04() {
        return nota04;
    }

    public void setNota04(double nota04) {
        this.nota04 = nota04;
    }

    public void cauc () {
        Scanner s = new Scanner(System.in);
        System.out.println("Digite a nota:");
        double nota01 = s.nextDouble() ;
        System.out.println("Digite a nota:");
        double nota02 = s.nextDouble() ;
        System.out.println("Digite a nota:");
        double nota03 = s.nextDouble() ;;
        System.out.println("Digite a nota:");
        double nota04 = s.nextDouble() ;;
        double media;
        setNota01( nota01);
        setNota02(nota02);
        setNota03( nota03);
        setNota04(nota04);
        media = (nota01+nota02+nota03+nota04)/4;
        System.out.println("A media do aluno é:"+media);
        if (media>=7) {
            System.out.println("APROVADO");
        } else if (media>=5) {
            System.out.println("RECUPERAÇÃO");
        }
        else {
            System.out.println("REPROVADO");

        }
        }


  }

