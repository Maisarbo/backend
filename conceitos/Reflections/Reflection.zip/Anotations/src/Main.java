import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

public class Main {
    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa("Maisa", "Rua ", 20);

        System.out.println(pessoa.getNome());
        System.out.println("Métodos");
        Annotation[] annotations = pessoa.getClass().getAnnotations();
        for (Annotation an: annotations){
            System.out.println("Annotation type: " + an.annotationType());
        }

        if(pessoa.getClass().isAnnotationPresent(Tabela.class)){
            Tabela table = pessoa.getClass().getAnnotation(Tabela.class);

            System.out.println(table);
        }
    }

}