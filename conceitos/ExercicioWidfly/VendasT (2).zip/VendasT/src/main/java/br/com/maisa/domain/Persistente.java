package br.com.maisa.domain;

public interface Persistente {

	public Long getId();
	
	public void setId(Long id);
}