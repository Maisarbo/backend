package br.com.maisa.service;

import java.util.List;

import br.com.maisa.domain.Cliente;
import br.com.maisa.exceptions.DAOException;
import br.com.maisa.services.generic.IGenericService;

/**
 * @author rodrigo.pires
 *
 */
public interface IClienteService extends IGenericService<Cliente, Long> {

	Cliente buscarPorCPF(Long cpf) throws DAOException;

	List<Cliente> filtrarClientes(String query);

}