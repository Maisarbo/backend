package br.com.maisa.dao;

import br.com.maisa.domain.Carro;

public interface ICarroDao {
	
	Carro cadastrar(Carro carro);

}
