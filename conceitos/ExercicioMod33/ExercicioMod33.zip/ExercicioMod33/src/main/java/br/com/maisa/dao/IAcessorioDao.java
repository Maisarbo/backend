package br.com.maisa.dao;

import br.com.maisa.domain.Acessorio;

public interface IAcessorioDao {

	Acessorio cadastrar(Acessorio acessorio);

}
