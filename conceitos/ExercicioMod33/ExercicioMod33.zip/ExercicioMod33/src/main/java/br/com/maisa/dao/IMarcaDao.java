package br.com.maisa.dao;

import br.com.maisa.domain.Marca;

public interface IMarcaDao {

	Marca cadastrar(Marca marca);

}
