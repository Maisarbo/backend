package br.com.maisa;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import br.com.maisa.dao.IMarcaDao;
import br.com.maisa.dao.MarcaDao;
import br.com.maisa.domain.Marca;

public class MarcaTest {
private IMarcaDao marcaDao;
	
	public MarcaTest() {
		marcaDao = new MarcaDao();
	}

	@Test
	public void cadastrar() {
		Marca marca = new Marca();
		marca.setCodigo("aaa");
		marca.setNome("Ford");
		marca = marcaDao.cadastrar(marca);
		
		assertNotNull(marca);
		assertNotNull(marca.getId());
	}
}

