package br.com.maisa;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import br.com.maisa.dao.AcessorioDao;
import br.com.maisa.dao.CarroDao;
import br.com.maisa.dao.IAcessorioDao;
import br.com.maisa.dao.ICarroDao;
import br.com.maisa.dao.IMarcaDao;
import br.com.maisa.dao.MarcaDao;
import br.com.maisa.domain.Acessorio;
import br.com.maisa.domain.Carro;
import br.com.maisa.domain.Marca;


	public class CarroTest {
	
	
	
	private ICarroDao carroDao;
	private IMarcaDao marcaDao;
	private IAcessorioDao acessorioDao;
	
	public CarroTest() {
		carroDao = new CarroDao();
		marcaDao = new MarcaDao();
		acessorioDao = new AcessorioDao();

	}
	
	private Carro carro;
	
	@Test
	public void cadastrar() {
		Carro carro = criarCarro("sksee");
		assertNotNull(carro);
		assertNotNull(carro.getId());
	}
	private Carro criarCarro(String codigo) {
		Carro carro = new Carro();
		Marca marca = criarMarca("M7575d");
		Acessorio acessorio= criarAcessorio("A55d7");
	
		carro.setCodigo("C775d");
		carro.setModelo("Palido77");
		carro.add(acessorio);
		carro.setMarca(marca);
		return carroDao.cadastrar(carro);
		
	}
	private Acessorio criarAcessorio(String codigo) {
		Acessorio acessorio = new Acessorio();
		acessorio.setCodigo(codigo);
		acessorio.setNome("acessordio775");
		acessorio.add(carro);
		return acessorioDao.cadastrar(acessorio);
	}

	private Marca criarMarca(String codigo) {
		Marca marca = new Marca();
		marca.setCodigo(codigo);
		marca.setNome("Fiat77d5");
		
		return marcaDao.cadastrar(marca);
	}


	}
