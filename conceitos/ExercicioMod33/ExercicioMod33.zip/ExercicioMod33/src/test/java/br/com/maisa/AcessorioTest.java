package br.com.maisa;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import br.com.maisa.dao.AcessorioDao;
import br.com.maisa.dao.IAcessorioDao;
import br.com.maisa.domain.Acessorio;



public class AcessorioTest {

private IAcessorioDao acessorioDao;
	
	public AcessorioTest() {
		acessorioDao = new AcessorioDao();
	}

	@Test
	public void cadastrar() {
		Acessorio acessorio = new Acessorio();
		acessorio.setCodigo("aaa6");
		acessorio.setNome("acessorio");
		acessorio.add(null);
		acessorio = acessorioDao.cadastrar(acessorio);
		
		assertNotNull(acessorio);
		
	}
}
