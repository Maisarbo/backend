import java.util.HashMap;

public class FatorialTopDown {
	private static final HashMap<Integer, Long> memoria = new HashMap<>();
	public static long calcularFatorial(int n) {
		if (n <0) {
			return -1;
		}else if (n ==0 ||n ==1) {
			return 1;
				
			}else if (memoria.containsKey(n)){
				return memoria.get(n);
			}else {
				long resultado = n *calcularFatorial(n-1);
				memoria.put(n, resultado);
				return resultado;
		}
	}
	public static void main(String[] args) {
	       int numero = 102;
	       long fatorial = calcularFatorial(numero);
	       System.out.println("Fatorial de " + numero + ":" +fatorial);
	}}


