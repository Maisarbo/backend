public class Fatorial {
  
	public static long calcularFatorial(int n) {
		if (n<0) {
			return -1;
		}else if (n ==0|| n==1) {
			return 1;
		}else {
			return n * calcularFatorial(n-1);
		}
	
	}

    public static void main(String[] args) {
       int numero = 102;
       long fatorial = calcularFatorial(numero);
       System.out.println("Fatorial de " + numero + ":" +fatorial);
}}