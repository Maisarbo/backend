
public class FatorialBottomUp {

	public static long calcularFatorial(int n) {
		if (n<0) {
			return -1;
		}else if (n ==0 ||n ==1) {
			return 1;
		}else {
			long [] resultados = new long[n+1];
			resultados[0]=1;
		
		for(int i =1; i<=n;i++) {
			resultados[i] = i* resultados[i-1];
		}
		return resultados[n];
	}
	}
	public static void main(String[] args) {
	       int numero = 102;
	       long fatorial = calcularFatorial(numero);
	       System.out.println("Fatorial de " + numero + ":" +fatorial);
	}}
