package br.com.maisa.domain;

/*Classe que representa uma calculadora simples*/
public class Calculadora {

	/*Soma dois numeros inteiros*/
	public int adicionar(int primeiroTermo, int segundoTermo) {
		return primeiroTermo+segundoTermo;
		
	}
	/*Subtrai minuendo do subtrendo*/
	public int subtrair(int minuendo, int subtraendo) {
		return minuendo-subtraendo;
		
	}
	/*Multiplica o multiplicando pelo multiplicador*/
	public int multiplicar(int multiplicando, int multiplicador) {
		return multiplicando*multiplicador;
	}
	/*Dividi o numerador pelo denominador*/
	public float dividir(int numerador, int denominador) {
		if (denominador ==0) {
			throw new ArithmeticException("Divisão por zero não é permitida");
		}
		return numerador/denominador;
	}
}
