package br.com.maisa.domain;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FibonacciTeste {
Fibonacci fibonacci = new Fibonacci();
	@Test
	public void Test() {
		long elemento =  Fibonacci.encontrarElementoPD(6);
		assertEquals(elemento, 8);
	}
	@Test
	public void Test1() {
		int n = 1;
		long elemento =  Fibonacci.encontrarElementoPD(n);
		assertEquals(elemento, n);
	}
	@Test
	public void Test2() {
		int n = 0;
		long elemento =  Fibonacci.encontrarElementoPD(n);
		assertEquals(elemento, n);
	}
	
}
