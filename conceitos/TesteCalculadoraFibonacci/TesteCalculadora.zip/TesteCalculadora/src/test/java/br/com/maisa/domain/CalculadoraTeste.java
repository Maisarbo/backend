package br.com.maisa.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.Test;

public class CalculadoraTeste {
	Calculadora calculadora= new Calculadora();
	
	@Test	
	public void test() {

	int resultado = calculadora.adicionar(5,4);
	assertEquals(resultado, 9);
	}
	@Test
	public void test1() {
	
	int resultado = calculadora.subtrair(5,4);
	assertEquals(resultado, 1);
	}
	@Test
	public void test2() {
		int resultado = calculadora.multiplicar(5,2);
		assertEquals(resultado, 10);
	}

	@Test
	public void test3() {
	int a = 6;
	int b = 2;
	if (b ==0 ) {
	
			assertThrows(ArithmeticException.class, () -> {
				float resultado = calculadora.dividir(a,b);
			});}else {
				float resultado = calculadora.dividir(a,b);
				assertEquals(resultado,3,0.01);}
	}
			
	
}