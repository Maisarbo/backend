package br.com.maisa.domain;

public class Calculadora {

	public int adicionar(int a, int b) {
		return a+b;
		
	}
	public int subtrair(int a, int b) {
		return a-b;
		
	}
	public int multiplicar(int a, int b) {
		return a*b;
	}
	public float dividir(int a, int b) {
		if (b ==0) {
			throw new ArithmeticException("Divisão por zero não é permitida");
		}
		return a/b;
	}
}
