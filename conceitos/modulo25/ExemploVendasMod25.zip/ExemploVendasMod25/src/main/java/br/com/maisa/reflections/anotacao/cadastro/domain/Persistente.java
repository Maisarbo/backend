package br.com.maisa.reflections.anotacao.cadastro.domain;

public interface Persistente {

}
