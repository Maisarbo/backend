package br.com.maisa.dao;

import br.com.maisa.domain.Cliente;
import br.com.maisa.reflections.anotacao.cadastro.dao.generic.IGenericDAO;

public interface IClienteDAO extends IGenericDAO<Cliente> {

}
