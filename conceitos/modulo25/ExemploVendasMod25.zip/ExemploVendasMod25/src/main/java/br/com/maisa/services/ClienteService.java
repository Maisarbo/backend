package br.com.maisa.services;

import br.com.maisa.dao.ClienteDAO;
import br.com.maisa.dao.IClienteDAO;
import br.com.maisa.domain.Cliente;
import br.com.maisa.reflections.anotacao.cadastro.dao.generic.IGenericDAO;
import br.com.maisa.reflections.anotacao.cadastro.domain.Persistente;
import br.com.maisa.reflections.anotacao.cadastro.exception.TipoChaveNaoEncontradaException;

public class ClienteService implements IClienteService {

	private IClienteDAO clienteDAO;

	public ClienteService(IClienteDAO clienteDAO) {
		this.clienteDAO = clienteDAO;
	}

	@Override
	public Boolean salvar(Cliente entity) throws TipoChaveNaoEncontradaException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void excluir(Long cpf) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void alterar(Cliente entity) throws TipoChaveNaoEncontradaException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Cliente buscarPorCpf(Long cpf) {
		// TODO Auto-generated method stub
		return clienteDAO.consultar(cpf);
	}}



	
	//private IClienteDAO clienteDAO;
	
	//public ClienteService(IClienteDAO clienteDAO) {
		//this.clienteDAO = clienteDAO;
	//}

	//@Override
	//public Boolean salvar(Cliente cliente) throws TipoChaveNaoEncontradaException{
		//return clienteDAO.cadastrar(cliente);

	//}

	//@Override
	//public Cliente buscarPorCPF(Long cpf) {
		//return clienteDAO.consultar(cpf);
	//}

	//@Override
	//public void excluir(Long cpf) {
		//clienteDAO.excluir(cpf);
		
	//}

	//@Override
	//public void alterar(Cliente cliente)throws TipoChaveNaoEncontradaException {
	
		//clienteDAO.alterar(cliente);
		
	//}
	
	


