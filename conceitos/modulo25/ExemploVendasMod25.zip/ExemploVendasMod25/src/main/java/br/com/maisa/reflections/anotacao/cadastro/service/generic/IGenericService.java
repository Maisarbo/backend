package br.com.maisa.reflections.anotacao.cadastro.service.generic;

import br.com.maisa.domain.Cliente;
import br.com.maisa.reflections.anotacao.cadastro.domain.Persistente;
import br.com.maisa.reflections.anotacao.cadastro.exception.TipoChaveNaoEncontradaException;
public interface IGenericService <T extends Persistente> {
	

		public Boolean salvar(T entity) throws TipoChaveNaoEncontradaException;

		public void excluir(Long cpf);

		public void alterar(T entity)throws TipoChaveNaoEncontradaException;

		public Cliente buscarPorCpf(Long cpf);

}
