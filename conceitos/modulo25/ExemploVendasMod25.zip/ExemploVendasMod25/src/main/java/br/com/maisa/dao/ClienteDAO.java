package br.com.maisa.dao;

import java.util.Collection;

import br.com.maisa.domain.Cliente;
//import br.com.maisa.reflections.anotacao.cadastro.dao.generic.E;
import br.com.maisa.reflections.anotacao.cadastro.dao.generic.GenericDAO;
import br.com.maisa.reflections.anotacao.cadastro.dao.generic.IGenericDAO;
import br.com.maisa.reflections.anotacao.cadastro.exception.TipoChaveNaoEncontradaException;


public class ClienteDAO  extends GenericDAO<Cliente> implements IClienteDAO {

	
	public ClienteDAO() {
		super();
	}

	@Override
	public Class<Cliente> getTipoClasse() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void atualiarDados(Cliente entity, Cliente entityCadastrado) {
		// TODO Auto-generated method stub
		
	}



}
