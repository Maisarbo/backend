package br.com.maisa.reflections.anotacao.cadastro.service.generic;

import br.com.maisa.dao.ClienteDAO;
import br.com.maisa.dao.IClienteDAO;
import br.com.maisa.domain.Cliente;
import br.com.maisa.reflections.anotacao.cadastro.dao.generic.IGenericDAO;
import br.com.maisa.reflections.anotacao.cadastro.domain.Persistente;
import br.com.maisa.reflections.anotacao.cadastro.exception.TipoChaveNaoEncontradaException;

public class GenericService<T extends Persistente> implements IGenericService<T>  {
	
	
private IGenericDAO clienteDAO;
	
	public GenericService(IGenericDAO clienteDAO) {
		this.clienteDAO = clienteDAO;
	}

	@Override
	public Boolean salvar(T entity) throws TipoChaveNaoEncontradaException {
		return clienteDAO.cadastrar(entity);
	}

	@Override
	public Cliente buscarPorCpf(Long cpf) {
		return (Cliente) clienteDAO.consultar(cpf);
	}

	@Override
	public void excluir(Long cpf) {
		clienteDAO.excluir(cpf);
		
	}

	@Override
	public void alterar(T entity) throws TipoChaveNaoEncontradaException {
       clienteDAO.alterar(entity);
		
	}

}
