package br.com.maisa.services;

import br.com.maisa.domain.Cliente;
import br.com.maisa.reflections.anotacao.cadastro.exception.TipoChaveNaoEncontradaException;
import br.com.maisa.reflections.anotacao.cadastro.service.generic.IGenericService;

public interface IClienteService extends IGenericService<Cliente> {


	//Boolean salvar(Cliente cliente) throws TipoChaveNaoEncontradaException;

	//Cliente buscarPorCPF(Long cpf);
	
	//void excluir(Long cpf);

	//void alterar(Cliente cliente)throws TipoChaveNaoEncontradaException;



}
