package br.com.maisa.dao.jpa;

import br.com.maisa.dao.generic.jpa.IGenericJapDAO;
import br.com.maisa.domain.jpa.ProdutoJpa;

public interface IProdutoJpaDAO extends IGenericJapDAO<ProdutoJpa, Long>{

}
