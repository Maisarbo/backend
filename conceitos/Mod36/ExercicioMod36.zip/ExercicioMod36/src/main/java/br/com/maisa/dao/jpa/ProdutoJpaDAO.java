package br.com.maisa.dao.jpa;


import br.com.maisa.dao.generic.jpa.GenericJpaDB1DAO;
import br.com.maisa.domain.jpa.ProdutoJpa;


public class ProdutoJpaDAO extends GenericJpaDB1DAO<ProdutoJpa, Long> implements IProdutoJpaDAO {

	public ProdutoJpaDAO() {
		super(ProdutoJpa.class);
	}

}