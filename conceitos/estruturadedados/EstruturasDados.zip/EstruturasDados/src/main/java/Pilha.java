
public class Pilha {
	private int capacidade;
	private int top;
	private int[]array;
	
	public Pilha(int capacidade) {
		this.capacidade = capacidade;
		this.top = -1;
		this.array = new int[capacidade];
	}
	
	public void push(int elemento) {
		if (top == capacidade -1) {
			System.out.println("Erro: Pilha cheia, não é possivel empilhar");
		    return;
		}
		array[++top] = elemento;
		System.out.println(elemento + "empilhado na pilha");
	}
	
	public int pop() {
		if(isEmpty()) {
			System.out.println("Erro: Pilha vazia. Não é possivel desempilhar");
		    return -1;
		}
		return array[top--];
	}
	
	public int top() {
		if(isEmpty()) {
			System.out.println("Erro: Pilha vazia.Não há topo para obter");
		    return -1;
		}
		return array[top];
	}
	
	public boolean isEmpty() {
		return top ==-1;
	}
	
	public int size() {
		return top + 1; 
	}
	

}
