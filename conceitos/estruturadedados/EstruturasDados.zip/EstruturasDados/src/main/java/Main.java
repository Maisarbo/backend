
public class Main {
	public static void main (String[] args) {
		Pilha pilha = new Pilha(10);
		pilha.push(6);
		pilha.push(12);
		pilha.push(18);
		int topo = pilha.top();
		System.out.println("topo é " + topo);
		Fila fila = new Fila();
		fila.enqueue(5);
		fila.enqueue(10);
		fila.enqueue(15);
		boolean vazia = fila.isEmpty();
		int frente = fila.front();
		int fim = fila.rear();
		System.out.println(frente);
		System.out.println(fim);
		System.out.println(vazia);
	
		ListaEncadeada myList = new ListaEncadeada();
		
		myList.insert(30, 0);
		myList.insert(10, 1);
		myList.insert(20, 2);
		
		myList.printList();
		int tamanho = myList.size();
		System.out.println(tamanho);
	}

}
