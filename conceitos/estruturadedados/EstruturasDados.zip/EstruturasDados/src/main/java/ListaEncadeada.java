public class ListaEncadeada {
	Node head;
	
	public ListaEncadeada() {
		this.head = null;
	}
	
	public void push(int data) {
		Node newNode = new Node(data);
		newNode.next = head;
		head = newNode;
	}
	public int pop() {
		if (head == null) {
			throw new IllegalStateException("Cannot pop from an empty list");
		}
		int poppedData = head.data;
		head = head.next;
		return poppedData;
	}
	public void insert (int data, int position) {
		if (position < 0) {
			throw new IllegalArgumentException ("Position cannot be neagtive");
		}
		Node newNode = new Node(data);
		
		if (position ==0) {
			newNode.next = head;
			head = newNode;
	}else {
		Node current = head;
		for (int i =0;i<position -1; i++) {
			if (current == null) {
				throw new IllegalArgumentException("Position out of bounds");
			}
			current = current.next;
		}
		newNode.next = current.next;
		current.next = newNode;
	}
}
	public void remove  (int position) {
		if (position <0 || head ==null) {
			throw new IllegalArgumentException("Invalid position or empty list");
		}
		if (position ==0) {
			head = head.next;
		}else {
			Node current = head;
			Node previous = null;
			
			for (int i = 0;i<position; i++) {
				if(current == null) {
					throw new IllegalArgumentException("Position out of bounds");
				}
				previous = current;
				current = current.next;
			}
			if (current == null) {
				throw new IllegalArgumentException("Position out of bounds");
			}
			previous.next = current.next;
		}
	}
	
	public int elementAt(int position) {
		if (position <0 || head == null) {
			throw new IllegalArgumentException("Invalid position or empty list");
		}
		Node current = head;
		for (int i =0;i <position;i++) {
			if (current == null) {
				throw new IllegalArgumentException("Position out of bounds");
			}
			current = current.next;
			}
		if (current == null) {
			throw new IllegalArgumentException("Position out of bounds");
		}
		return current.data;
		}
	

   public int size() {
	   int count = 0;
	   Node current = head;
	   
	   while (current != null) {
		   count ++;
		   current = current.next;
	   }
	   return count;
   }
   public void printList() {
	   Node current = head;
	   while (current!= null) {
		   System.out.println(current.data + " ");
		   current = current.next;
	   }
	   System.out.println();
   }
   
}