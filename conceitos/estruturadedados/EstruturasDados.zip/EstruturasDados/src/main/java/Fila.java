
public class Fila {

	private Node front;
	private Node end;
	
	public Fila() {
		this.front = null;
		this.end = null;
		
	}
	 
	public void enqueue(int data) {
		Node newNode = new Node(data);
		
		if (end == null) {
			front = end = newNode;
			return;
		}
		
		end.next = newNode;
		end = newNode;
	}
	
	public int dequeue() {
		if(front == null) {
			System.out.println("Erro: Fila não é possivel remover");
		    return -1;
		}
		int dataDequeue = front.data;
		front = front.next;
		
		if (front ==null) {
			end = null;
		}
		
		return dataDequeue;
	}
	
	public boolean isEmpty() {
		return front == null;
	}
	
	public int size() {
		if (isEmpty()) {
			return 0;
			
		}
		
		int size =0;
		Node actual = front;
		
		while (actual != null) {
			size++;
			actual = actual.next;
		}
		
		return size;
	}
	public int front() {
		if (isEmpty()) {
			System.out.println("Erro: Fila vazia, não é possivel obter o elemento na frente");
			return -1;}
		return front.data;
		}
	
   public int rear() {
	   if (isEmpty()) {
		System.out.println("Erro: Fila vazia, não é possivel obter o elemento do fim da fila");
		return -1;}
	return end.data;
	}

}

