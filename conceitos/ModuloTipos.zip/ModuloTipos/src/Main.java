import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
import java.util.Scanner; // import the Scanner class
public class Main {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite sua idade:");
        int idade = teclado.nextInt();
        Integer i = idade;
        System.out.println(i.getClass());
    }
}
