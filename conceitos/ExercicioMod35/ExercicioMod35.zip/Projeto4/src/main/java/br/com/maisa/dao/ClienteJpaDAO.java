package br.com.maisa.dao;

import br.com.maisa.dao.generic.GenericJpaDAO;
import br.com.maisa.domain.ClienteJpa;
public class ClienteJpaDAO extends GenericJpaDAO<ClienteJpa, Long> implements IClienteJpaDAO {

	public ClienteJpaDAO() {
		super(ClienteJpa.class);
	}

}