package br.com.maisa.dao;

public interface Persistente {
	 //public Long getCodigo();
	
		public Long getId();
		
		public void setId(Long id);
}
