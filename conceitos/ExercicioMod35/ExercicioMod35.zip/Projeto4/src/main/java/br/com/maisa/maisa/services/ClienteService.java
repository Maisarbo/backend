package br.com.maisa.maisa.services;

import br.com.maisa.dao.IClienteJpaDAO;
import br.com.maisa.domain.ClienteJpa;
import br.com.maisa.exceptions.DAOException;
import br.com.maisa.exceptions.MaisDeUmRegistroException;
import br.com.maisa.exceptions.TableException;
import br.com.maisa.maisa.services.generic.jpa.GenericJpaService;

public class ClienteService extends GenericJpaService<ClienteJpa, Long> implements IClienteService {
	
	//private IClienteDAO clienteDAO;
	
	public ClienteService(IClienteJpaDAO clienteDAO) {
		super(clienteDAO);
		//this.clienteDAO = clienteDAO;
	}

//	@Override
//	public Boolean salvar(Cliente cliente) throws TipoChaveNaoEncontradaException {
//		return clienteDAO.cadastrar(cliente);
//	}

	@Override
	public ClienteJpa buscarPorCPF(Long cpf) throws DAOException {
		try {
			return this.dao.consultar(cpf);
		} catch (MaisDeUmRegistroException | TableException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

//	@Override
//	public void excluir(Long cpf) {
//		clienteDAO.excluir(cpf);
//	}
//
//	@Override
//	public void alterar(Cliente cliente) throws TipoChaveNaoEncontradaException{
//		clienteDAO.alterar(cliente);
//	}

}
