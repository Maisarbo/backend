package br.com.maisa.maisa.services;


import javax.persistence.Entity;

import br.com.maisa.dao.IProdutoJpaDAO;
import br.com.maisa.dao.ProdutoJpaDAO;
import br.com.maisa.dao.generic.IGenericJapDAO;
import br.com.maisa.domain.ProdutoJpa;
import br.com.maisa.maisa.services.generic.jpa.GenericJpaService;

public class ProdutoService extends GenericJpaService<ProdutoJpa, Long> implements IProdutoService {

	public ProdutoService(IProdutoJpaDAO produtoDAO) {
		super(produtoDAO);
		// TODO Auto-generated constructor stub
	}


	

	

	


	

}
