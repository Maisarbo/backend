package br.com.maisa.maisa.services;

import br.com.maisa.domain.ClienteJpa;
import br.com.maisa.exceptions.DAOException;
import br.com.maisa.maisa.services.generic.jpa.IGenericJpaService;

public interface IClienteService extends IGenericJpaService<ClienteJpa, Long> {

//	Boolean cadastrar(Cliente cliente) throws TipoChaveNaoEncontradaException;
//
	ClienteJpa buscarPorCPF(Long cpf) throws DAOException;
//
//	void excluir(Long cpf);
//
//	void alterar(Cliente cliente) throws TipoChaveNaoEncontradaException;

}
