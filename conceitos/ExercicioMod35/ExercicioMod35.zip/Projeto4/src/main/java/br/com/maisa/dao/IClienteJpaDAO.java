package br.com.maisa.dao;

import br.com.maisa.dao.generic.IGenericJapDAO;
import br.com.maisa.domain.ClienteJpa;

public interface IClienteJpaDAO extends IGenericJapDAO<ClienteJpa, Long>{

}
