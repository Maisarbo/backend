package br.com.maisa.dao;

import br.com.maisa.dao.generic.GenericJpaDAO;
import br.com.maisa.domain.ProdutoJpa;

public class ProdutoJpaDAO extends GenericJpaDAO<ProdutoJpa, Long> implements IProdutoJpaDAO {

	public ProdutoJpaDAO() {
		super(ProdutoJpa.class);
	}

}