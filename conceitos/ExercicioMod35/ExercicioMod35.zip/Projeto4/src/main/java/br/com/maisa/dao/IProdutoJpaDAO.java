package br.com.maisa.dao;

import br.com.maisa.dao.generic.IGenericJapDAO;
import br.com.maisa.domain.ProdutoJpa;

public interface IProdutoJpaDAO extends IGenericJapDAO<ProdutoJpa, Long>{

	

}
