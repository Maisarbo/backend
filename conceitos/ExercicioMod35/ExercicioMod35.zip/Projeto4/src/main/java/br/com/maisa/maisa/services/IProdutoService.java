package br.com.maisa.maisa.services;

import br.com.maisa.domain.ProdutoJpa;
import br.com.maisa.maisa.services.generic.jpa.IGenericJpaService;

public interface IProdutoService extends IGenericJpaService<ProdutoJpa, Long> {

}
