package br.com.maisa.services;

import br.com.maisa.dao.ClienteDaoMock;
import br.com.maisa.domain.ClienteJpa;
import br.com.maisa.exceptions.DAOException;
import br.com.maisa.exceptions.TipoChaveNaoEncontradaException;
import br.com.maisa.maisa.services.ClienteService;
import br.com.maisa.maisa.services.IClienteService;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import br.com.maisa.dao.*;
public class ClienteServiceTest {
	
	private IClienteService clienteService;
	
	private ClienteJpa cliente;
	
	public ClienteServiceTest() {
		IClienteJpaDAO dao = new ClienteDaoMock();
		clienteService = new ClienteService(dao);
	}
	
	@Before
	public void init() {
		cliente = new ClienteJpa();
		cliente.setCpf(12312312312L);
		cliente.setNome("Rodrigo");
		cliente.setCidade("São Paulo");
		cliente.setEnd("End");
		cliente.setEstado("SP");
		cliente.setNumero(10);
		cliente.setTel(1199999999L);
		
	}
	
	@Test
	public void pesquisarCliente() throws DAOException {
		ClienteJpa clienteConsultado = clienteService.buscarPorCPF(cliente.getCpf());
	    assertNotNull(clienteConsultado);
	}
	
	@Test
	public void salvarCliente() throws TipoChaveNaoEncontradaException, DAOException {
		ClienteJpa retorno = clienteService.cadastrar(cliente);
		
		assertNotNull(retorno);
	}
	
	@Test
	public void excluirCliente() throws DAOException {
		clienteService.excluir(cliente);
	}
	
	@Test
	public void alterarCliente() throws TipoChaveNaoEncontradaException, DAOException {
		cliente.setNome("Rodrigo Pires");
		clienteService.alterar(cliente);
		
		assertEquals("Rodrigo Pires", cliente.getNome());
	}
}
