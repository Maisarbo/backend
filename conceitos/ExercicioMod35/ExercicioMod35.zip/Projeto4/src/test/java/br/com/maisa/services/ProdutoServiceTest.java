package br.com.maisa.services;

import br.com.maisa.domain.ProdutoJpa;
import br.com.maisa.exceptions.DAOException;
import br.com.maisa.exceptions.MaisDeUmRegistroException;
import br.com.maisa.exceptions.TableException;
import br.com.maisa.exceptions.TipoChaveNaoEncontradaException;
import br.com.maisa.maisa.services.IProdutoService;
import br.com.maisa.maisa.services.ProdutoService;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import br.com.maisa.dao.*;
import br.com.maisa.dao.generic.IGenericJapDAO;

public class ProdutoServiceTest {

	private IProdutoService produtoService;
	
	private ProdutoJpa produto;
	
	public ProdutoServiceTest() {
		IProdutoJpaDAO dao = new ProdutoDaoMock();
		produtoService = new ProdutoService(dao);
	}
	
	@Before
	public void init() {
		produto = new ProdutoJpa();
		produto.setCodigo("A1");
		produto.setDescricao("Produto 1");
		produto.setNome("Produto 1");
		produto.setValor(BigDecimal.TEN);
	}
	
	@Test
	public void pesquisar() throws DAOException, MaisDeUmRegistroException, TableException {
		ProdutoJpa produtor = this.produtoService.consultar(produto.getId());
		assertNotNull(produtor);
	}
	
	@Test
	public void salvar() throws TipoChaveNaoEncontradaException, DAOException {
		ProdutoJpa retorno = produtoService.cadastrar(produto);
		assertNotNull(retorno);
	}
	
	@Test
	public void excluir() throws DAOException {
		produtoService.excluir(produto);
	}
	
	@Test
	public void alterarCliente() throws TipoChaveNaoEncontradaException, DAOException {
		produto.setNome("Rodrigo Pires");
		produtoService.alterar(produto);
		
		assertEquals("Rodrigo Pires", produto.getNome());
	}
}
