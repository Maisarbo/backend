package br.com.maisa.dao;

import java.util.Collection;

import br.com.maisa.domain.ProdutoJpa;
import br.com.maisa.exceptions.DAOException;
import br.com.maisa.exceptions.MaisDeUmRegistroException;
import br.com.maisa.exceptions.TableException;
import br.com.maisa.exceptions.TipoChaveNaoEncontradaException;

public class ProdutoDaoMock implements IProdutoJpaDAO {

	@Override
	public ProdutoJpa cadastrar(ProdutoJpa entity) throws TipoChaveNaoEncontradaException, DAOException {
		// TODO Auto-generated method stub
		return entity;
	}

	@Override
	public void excluir(ProdutoJpa entity) throws DAOException {
		// TODO Auto-generated method stub
		
	}


	@Override
	public ProdutoJpa consultar(Long id) throws MaisDeUmRegistroException, TableException, DAOException {
		ProdutoJpa produto = new ProdutoJpa();
		produto.setId(id);
		produto.setCodigo("Test");
		return produto;
	}

	@Override
	public Collection<ProdutoJpa> buscarTodos() throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProdutoJpa alterar(ProdutoJpa entity) throws TipoChaveNaoEncontradaException, DAOException {
		// TODO Auto-generated method stub
		return null;
	}

}