package br.com.maisa.dao;

import java.util.Collection;

import br.com.maisa.domain.ClienteJpa;
import br.com.maisa.exceptions.DAOException;
import br.com.maisa.exceptions.MaisDeUmRegistroException;
import br.com.maisa.exceptions.TableException;
import br.com.maisa.exceptions.TipoChaveNaoEncontradaException;

public class ClienteDaoMock implements IClienteJpaDAO {

	@Override
	public ClienteJpa cadastrar(ClienteJpa entity) throws TipoChaveNaoEncontradaException, DAOException {
		// TODO Auto-generated method stub
		return entity;
	}

	@Override
	public void excluir(ClienteJpa entity) throws DAOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ClienteJpa alterar(ClienteJpa entity) throws TipoChaveNaoEncontradaException, DAOException {
		// TODO Auto-generated method stub
		return entity;
	}

	@Override
	public ClienteJpa consultar(Long id) throws MaisDeUmRegistroException, TableException, DAOException {
		ClienteJpa cliente = new ClienteJpa();
		cliente.setId(id);
		return cliente;
	}

	@Override
	public Collection<ClienteJpa> buscarTodos() throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	


}
