import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        // SEPARA POR GRUPOS DE ACORDO COM O SEXO
        System.out.println("Digite uma sequência de nomes,com - e a primeira letra do sexo, separados por virgula somente, sem espaço:EX.:MAISA-F,FABRICIO-M");
        String sed = s.nextLine();
        String [] y = sed.split(",");
        List<Aluno> lisa;
        lisa = new ArrayList<Aluno>();
        for (int xi = 0; y.length > xi; xi ++) {
            String[] cx = y[xi].split("-");

            for (String i : cx) {
                int vc = 0;
                Aluno ci = new Aluno();
                String x1 = cx[0];
                String x2 = cx[1];
                ci.setNome(x1);
                ci.setSexo(x2);
                lisa.add(ci);



                break;


            }}

        List<Aluno> listB = lisa.stream()
                        .filter(Aluno -> Aluno.getSexo().equals("F"))
                        .collect(Collectors.toList());
                        listB.forEach(System.out::println);

    }}
