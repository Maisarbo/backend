

import org.junit.Assert;
import org.junit.Test;
import org.junit.Assert;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

    public class Teste {
        @Test
        public void test(){
            List<Aluno> lis;
            lis = new ArrayList<Aluno>();
            Aluno aluno = new Aluno();
            aluno.setSexo("F");
            aluno.setNome("Maisa");
            Aluno aluno1 = new Aluno();
            aluno1.setSexo("M");
            aluno1.setNome("li");
            lis.add(aluno1);
            lis.add(aluno);
            List<Aluno> listB = lis.stream()
                    .filter(Aluno -> Aluno.getSexo().equals("F"))
                    .collect(Collectors.toList());
            listB.forEach(System.out::println);

            for (int i = 0;i < listB.toArray().length; i ++){
                Aluno cc = listB.get(i);
                System.out.println(cc.getSexo());
                Assert.assertEquals("M", cc.getSexo());
            }

        }}

