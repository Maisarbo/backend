public class Gol extends Carro{
    @Override
    public  int tempoChegada(int dis) {
        int x = getVelocidadeMedia();
        int x1 = dis/x;
        setTempo(x1);
        System.out.println("Ele gastará " +x1+ " horas");
        return x1;
    }
    }

