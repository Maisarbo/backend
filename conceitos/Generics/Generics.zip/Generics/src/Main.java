import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Civic civic = new Civic();
        Gol gol = new Gol();
        gol.setVelocidadeMedia(100);
        gol.tempoChegada(300);
        civic.setVelocidadeMedia(150);
        civic.tempoChegada(300);


        boolean b = gol.getTempo() > civic.getTempo();
        boolean c = civic.getTempo() > gol.getTempo();

        List<Carro> lisa;
        lisa = new ArrayList<Carro>();
        if (b == false && c == true){
            lisa.add(gol);
            lisa.add(civic);
            System.out.println(lisa);
        }else {
            lisa.add(civic);
            lisa.add(gol);
            System.out.println(lisa);
        }

    }

}