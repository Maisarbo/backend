public interface Carro {
    void tempoChegada(int dis);
    void exibirInfo();
}
