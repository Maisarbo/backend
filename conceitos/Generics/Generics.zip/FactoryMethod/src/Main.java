import java.util.ArrayList;
import java.util.List;

public class Main {



    public static void main(String args[]) {
        FabricaFiat carro = new FabricaFiat();
        carro.criarCarro();
        Palio palio = new Palio();
        palio.exibirInfo();
        palio.setVelocidadeMedia(100);
        palio.tempoChegada(300);

        FabricaVolks carroo = new FabricaVolks();
        carroo.criarCarro();
        Gol gol = new Gol();
        gol.exibirInfo();
        gol.setVelocidadeMedia(150);
        gol.tempoChegada(300);

        boolean b = gol.getTempo() > palio.getTempo();
        boolean c = palio.getTempo() > gol.getTempo();
        System.out.println(b);
        if (b ==false){
            System.out.println("O Gol chegará em primeiro lugar");
        }
        List<Carro> lisa;
        lisa = new ArrayList< Carro>();
        if (b == false && c == true){
            lisa.add(gol);
            lisa.add(palio);
            System.out.println(lisa);
        }


    }}