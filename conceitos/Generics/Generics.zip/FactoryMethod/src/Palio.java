public class Palio implements Carro{
    private int velocidadeMedia;

    public int getTempo() {
        return tempo;
    }

    public void setTempo(int tempo) {
        this.tempo = tempo;
    }

    private int tempo;
    public int getVelocidadeMedia() {
        return velocidadeMedia;
    }

    public void setVelocidadeMedia(int velocidadeMedia) {
        this.velocidadeMedia = velocidadeMedia;
    }
    @Override
    public void tempoChegada(int dis) {
        int x = getVelocidadeMedia();
        int x1 = dis/x;
        setTempo(x1);
        System.out.println("Ele gastará " +x1+ " horas");
    }

    @Override
    public void exibirInfo() {
        System.out.println("Modelo: Palio - Fabricante: Fiat");
    }
}
