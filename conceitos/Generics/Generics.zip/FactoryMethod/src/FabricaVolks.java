public class FabricaVolks implements FabricaCarro{
    @Override
    public Carro criarCarro() {
        return new Gol();
    }
}
