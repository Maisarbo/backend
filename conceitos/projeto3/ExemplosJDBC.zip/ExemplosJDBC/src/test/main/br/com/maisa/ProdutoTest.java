package br.com.maisa;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import br.com.maisa.dao.ProdutoDAO;
import br.com.maisa.dao.IProdutoDAO;

import br.com.maisa.domain.Produto;

public class ProdutoTest {
	
	@Test
	public void CadastrarTest() throws Exception {
	   
	  
	IProdutoDAO dao = new ProdutoDAO();
	   
	Produto produto = new Produto();
	//---------Cadastrar produto banco de dados
	produto.setId(9L);
	produto.setNome("Rodrigo Pires");
	produto.setCodigo("125AB");
	produto.setPreco(50.50);
	dao.cadastrar(produto);
	  
	
	//--------Atualizar nome banco de dados
	Long id = 9l;
	produto.setId(id);
	produto.setNome("mai");
	dao.atualizar(produto);
    
	List list = dao.buscarTodos();
    assertNotNull(list);
	Produto produtoBD = dao.consultar(produto.getCodigo());
	assertNotNull(produtoBD);
	assertNotNull(produtoBD.getId());
	assertEquals (produto.getCodigo(), produtoBD.getCodigo());
  //falha, porque o nome é atualizado	
	assertEquals(produto.getNome(), produtoBD.getNome());
  
  //----------Exclui registro banco de dados
  //Produto produtoBD = dao.consultar(produto.getCodigo());
  //Integer qtdDel = dao.excluir(produtoBD);
  //assertNotNull(qtdDel);
	
		
	}

}
