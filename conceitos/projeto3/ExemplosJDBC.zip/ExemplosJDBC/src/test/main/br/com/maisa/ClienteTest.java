package br.com.maisa;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import br.com.maisa.dao.ClienteDAO;
import  br.com.maisa.dao.IClienteDAO;
import br.com.maisa.domain.Cliente;


public class ClienteTest {
	 @Test
		public void CadastrarTest() throws Exception {
		   
		  
		  IClienteDAO dao = new ClienteDAO();
		   
		Cliente cliente = new Cliente();
		//---------Cadastrar produto banco de dados
		
		
		cliente.setId(6L);
		cliente.setNome("Rodrigo Pires");
		cliente.setCodigo("125AB");
		dao.cadastrar(cliente);
		  
		
		//--------Atualizar nome banco de dados
		Long id = 6l;
		cliente.setId(id);
		cliente.setNome("mai");
		dao.atualizar(cliente);

		

	      List list = dao.buscarTodos();
	      assertNotNull(list);
		  Cliente clienteBD = dao.consultar(cliente.getCodigo());
		  assertNotNull(clienteBD);
		  assertNotNull(clienteBD.getId());
		  assertEquals (cliente.getCodigo(), clienteBD.getCodigo());
	    //falha, porque o nome é atualizado	
		 // assertEquals(cliente.getNome(), clienteBD.getNome());
		  
		//----------Exclui registro banco de dados
		//Cliente clienteBD = dao.consultar(cliente.getCodigo());
	   // Integer qtdDel = dao.excluir(clienteBD);
	    //assertNotNull(qtdDel);
		
			
		}}

	
	   
	   
	   
	   
	

	   
	   
	  
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	
