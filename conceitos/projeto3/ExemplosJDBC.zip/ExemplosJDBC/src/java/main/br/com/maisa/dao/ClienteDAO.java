package br.com.maisa.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.maisa.dao.jdbc.Connect;

import br.com.maisa.domain.Cliente;


public class ClienteDAO implements IClienteDAO{
	

	@Override
	public Integer cadastrar(Cliente cliente) throws Exception {
		Connect conexao = new Connect(); 
		conexao.conectar();
		try {
			PreparedStatement pst = conexao.conexao.prepareStatement("insert into tb_cliente_2(id,nome,codigo)values (?,?,?)");
			pst.setLong(1, cliente.getId());
			pst.setString(2,cliente.getNome());
			pst.setString(3,cliente.getCodigo());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null,"Salvo com sucesso!");
		}catch (SQLException ex) {
			JOptionPane.showMessageDialog(null,"Erro na inserção!\nErro: " + ex.getMessage());
		}
		return null;
	}
		
	
	@Override
	public Cliente consultar(String codigo)throws Exception {
		Connect conexao = new Connect(); 
		conexao.conectar();
	    PreparedStatement pst = null;
	    ResultSet rs = null;
	    Cliente cliente = null;
	    Connection connection = null;
	    try {
	    	
	    	String sql = "select * from tb_cliente_2 where codigo = ?";
	        pst = conexao.conexao.prepareStatement(sql);
	    	pst.setString(1, codigo);
	        rs = pst.executeQuery();
	        if (rs.next()) {
	        	cliente = new Cliente();
	        	cliente.setId(rs.getLong("id"));
	        	cliente.setCodigo(rs.getString("codigo"));
	        	cliente.setNome(rs.getString("nome"));
	        }
	         return cliente;
	} catch(Exception e) {
	    	throw e;
	    	
	    }finally {
	    	if (pst != null && !pst.isClosed()) {
	    		pst.close();
	    	}
	    	if (connection != null && !connection.isClosed()) {
	    		connection.close();
	    	}
	    	
	    	
	    }

	}


	@Override
	public Integer excluir(Cliente cliente) throws Exception {

		Connect conexao = new Connect(); 
		conexao.conectar();
		try {
			PreparedStatement pst = conexao.conexao.prepareStatement("delete from tb_cliente_2 where codigo = ?");
			pst.setString(1, cliente.getCodigo());
			 return pst.executeUpdate();
			//JOptionPane.showMessageDialog(null,"Salvo com sucesso!");
			//return pst.executeUpdate();
		}catch (SQLException ex) {
			JOptionPane.showMessageDialog(null,"Erro na exclusão!\nErro: " + ex.getMessage());
		}
		return null;
	}
	


	@Override
	public Integer atualizar(Cliente cliente) throws Exception {
		Connect conexao = new Connect(); 
		conexao.conectar();

		String sql = "update tb_cliente_2 set  nome =? where id = ?";
		try {
			PreparedStatement pst = conexao.conexao.prepareStatement(sql);
			
			pst.setString(1,cliente.getNome() );
			pst.setLong(2, cliente.getId());
			//pst.setString(2, produto.getCodigo());
			//pst.setDouble(3, produto.getPreco());
			
			
			pst.executeUpdate();
			pst.close();
		
		}catch (SQLException ex) {
			 
			JOptionPane.showMessageDialog(null,"Erro na exclusão!\nErro: " + ex.getMessage());
		}
		return null;
	}


	@Override
	public List<Cliente> buscarTodos() throws Exception {
		Connect conexao = new Connect(); 
		conexao.conectar();
	    PreparedStatement pst = null;
	    ResultSet rs = null;
	    Cliente cliente = null;
	    Connection connection = null;
	    try {
	    	String sql = "select * from tb_cliente_2";
	        pst = conexao.conexao.prepareStatement(sql);
	        rs = pst.executeQuery();
	        List lista = new ArrayList();
	        while(rs.next()) {
	        	cliente = new Cliente();
	        	cliente.setId(rs.getLong("id"));
	        	cliente.setCodigo(rs.getString("codigo"));
	        	cliente.setNome(rs.getString("nome"));        	
	        	lista.add(cliente);
	        }
	         return lista;
	} catch(Exception e) {
	    	throw e;
	    	
	    }finally {
	    	if (pst != null && !pst.isClosed()) {
	    		pst.close();
	    	}
	    	if (connection != null && !connection.isClosed()) {
	    		connection.close();
	    	}
	    
	    	
	    	
	    }
	    }
	}

	
 




