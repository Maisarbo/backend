package br.com.maisa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import org.junit.Test;

import br.com.maisa.dao.jdbc.Connect;

import br.com.maisa.domain.Produto;

public class ProdutoDAO implements IProdutoDAO {

	@Override
	public Integer cadastrar(Produto produto) throws Exception {
		
		Connect conexao = new Connect(); 
		conexao.conectar();
		try {
			PreparedStatement pst = conexao.conexao.prepareStatement("insert into tb_produto_2(id,nome,codigo,preco)values (?,?,?,?)");
			pst.setLong(1, produto.getId());
			pst.setString(2,produto.getNome());
			pst.setString(3,produto.getCodigo());
			pst.setDouble(4,produto.getPreco());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null,"Salvo com sucesso!");
			//return pst.executeUpdate();
		}catch (SQLException ex) {
			JOptionPane.showMessageDialog(null,"Erro na inserção!\nErro: " + ex.getMessage());
		}
		return null;
	}

	@Override
	public Produto consultar(String codigo) throws Exception {
		Connect conexao = new Connect(); 
		conexao.conectar();
	    PreparedStatement pst = null;
	    ResultSet rs = null;
	    Produto produto = null;
	    Connection connection = null;
	    try {
	    	
	    	//connection = ConnectionFactory.getConnection();
	    	String sql = "select * from tb_produto_2 where codigo = ?";
	        pst = conexao.conexao.prepareStatement(sql);
	    	pst.setString(1, codigo);
	        rs = pst.executeQuery();
	        if (rs.next()) {
	        	produto = new Produto();
	        	produto.setId(rs.getLong("id"));
	        	produto.setCodigo(rs.getString("codigo"));
	        	produto.setNome(rs.getString("nome"));
	        	produto.setPreco(rs.getDouble("preco"));
	        }
	         return produto;
	} catch(Exception e) {
	    	throw e;
	    	
	    }finally {
	    	if (pst != null && !pst.isClosed()) {
	    		pst.close();
	    	}
	    	if (connection != null && !connection.isClosed()) {
	    		connection.close();
	    	}
	    	
	    	
	    }
	}
	@Override
	public Integer excluir(Produto produto) throws Exception {
		
		Connect conexao = new Connect(); 
		conexao.conectar();
		try {
			PreparedStatement pst = conexao.conexao.prepareStatement("delete from tb_produto_2 where codigo = ?");
			pst.setString(1, produto.getCodigo());
			 return pst.executeUpdate();
			//JOptionPane.showMessageDialog(null,"Salvo com sucesso!");
			//return pst.executeUpdate();
		}catch (SQLException ex) {
			JOptionPane.showMessageDialog(null,"Erro na exclusão!\nErro: " + ex.getMessage());
		}
		return null;
	}

	@Override
	public Integer atualizar(Produto produto) throws Exception {
		Connect conexao = new Connect(); 
		conexao.conectar();

		String sql = "update tb_produto_2 set  nome =? where id = ?";
		try {
			PreparedStatement pst = conexao.conexao.prepareStatement(sql);
			
			pst.setString(1,produto.getNome() );
			pst.setLong(2, produto.getId());
			//pst.setString(2, produto.getCodigo());
			//pst.setDouble(3, produto.getPreco());
			
			
			pst.executeUpdate();
			pst.close();
		
		}catch (SQLException ex) {
			 
			JOptionPane.showMessageDialog(null,"Erro na exclusão!\nErro: " + ex.getMessage());
		}
		return null;
	}

	
	
	
	@Override
	public List<Produto> buscarTodos() throws Exception {
		Connect conexao = new Connect(); 
		conexao.conectar();
	    PreparedStatement pst = null;
	    ResultSet rs = null;
	    Produto produto = null;
	    Connection connection = null;
	    try {
	    	String sql = "select * from tb_produto_2";
	        pst = conexao.conexao.prepareStatement(sql);
	        rs = pst.executeQuery();
	        List lista = new ArrayList();
	        while(rs.next()) {
	        	produto = new Produto();
	        	produto.setId(rs.getLong("id"));
	        	produto.setCodigo(rs.getString("codigo"));
	        	produto.setNome(rs.getString("nome"));
	        	produto.setPreco(rs.getDouble("preco"));
	        	
	        	lista.add(produto);
	        }
	         return lista;
	} catch(Exception e) {
	    	throw e;
	    	
	    }finally {
	    	if (pst != null && !pst.isClosed()) {
	    		pst.close();
	    	}
	    	if (connection != null && !connection.isClosed()) {
	    		connection.close();
	    	}
	    
	    	
	    	
	    }}}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


