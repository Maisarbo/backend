package br.com.maisa.dao.jdbc;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

import org.junit.Test;

public class Connect {
	public Statement stm;
	public ResultSet rs;
	private String driver = "org.postgresql.Driver";
	private String caminho = "jdbc:postgresql://localhost:5432/vendas_online_2";
	private String usuario = "postgres";
	private String senha = "1234";
	public Connection conexao;
	@Test
	public void conectar() {
		try {
			System.setProperty("jdbc.Drivers", driver);
			conexao = DriverManager.getConnection(caminho, usuario, senha);
			JOptionPane.showMessageDialog(null, "Conectado com sucesso!", "Banco de Dados", JOptionPane.INFORMATION_MESSAGE);
		}catch (SQLException ex) {
			Logger.getLogger(Connect.class.getName()).log(Level.SEVERE,null,ex);
			JOptionPane.showMessageDialog(null,"Erro de conexão!\nERRO: "+ ex.getMessage(), "Banco de Dados", JOptionPane.INFORMATION_MESSAGE);
		}
	
	}
	

}
