import java.lang.reflect.Array;
import java.util.*;
import java.io.*;


public class Main  {
    public static  void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Digite uma sequência de nomes, separados por virgula somente, sem espaço:");
        String lista = s.nextLine();

        String[] v = lista.split(",");
        ;
        List<String> lis;
        lis = new ArrayList<String>();
        for (String i : v) {
            lis.add(i);
        }
        Collections.sort(lis);
        System.out.println(lis);



       // SEPARA POR GRUPOS DE ACORDO COM O SEXO
        System.out.println("Digite uma sequência de nomes,com - e a primeira letra do sexo, separados por virgula somente, sem espaço:EX.:MAISA-F,FABRICIO-M");
        String sed = s.nextLine();
        String [] y = sed.split(",");
        List<Aluno> lisa;
        lisa = new ArrayList<Aluno>();
        List<Aluno> lsa;
        lsa = new ArrayList<Aluno>();
        for (int xi = 0; y.length > xi; xi ++) {
            String[] cx = y[xi].split("-");

            for (String i : cx) {
                int vc = 0;
                Aluno ci = new Aluno();
                String x1 = cx[0];
                String x2 = cx[1];
                String x3 = "M";
                String x5 = "m";
                ci.setNome(x1);
                ci.setSexo(x2);
                if(x3.equals(x2) || (x5.equals(x2))){
                    lisa.add(ci);
                }
                else {
                    lsa.add(ci);
                }
                break;


        }}


        System.out.println("Este é o grupo do sexo Masculino:" + lisa);
        System.out.println("Este é o grupo do sexo Feminino0" + lsa);


    }}