package br.com.maisa.services;

import br.com.maisa.domain.Produto;
import br.com.maisa.services.generic.IGenericService;

public interface IProdutoService extends IGenericService<Produto, String> {

}