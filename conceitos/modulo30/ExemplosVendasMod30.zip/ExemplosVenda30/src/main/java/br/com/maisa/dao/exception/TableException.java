package br.com.maisa.dao.exception;

public class TableException extends Exception {

	
	private static final long serialVersionUID = -7509649433607067138L;

	public TableException(String msg) {
		super(msg);
    }

}