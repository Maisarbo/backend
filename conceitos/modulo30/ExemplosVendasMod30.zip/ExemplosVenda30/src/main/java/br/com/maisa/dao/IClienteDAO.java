package br.com.maisa.dao;

import br.com.maisa.dao.generic.IGenericDAO;
import br.com.maisa.domain.Cliente;

public interface IClienteDAO extends IGenericDAO<Cliente, Long> {


}