public class Main {



    public static void main(String args[]) {
        FabricaFiat carro = new FabricaFiat();
        carro.criarCarro();
        Palio palio = new Palio();
        palio.exibirInfo();

    }}