public interface FabricaCarro {
    Carro criarCarro();
}
