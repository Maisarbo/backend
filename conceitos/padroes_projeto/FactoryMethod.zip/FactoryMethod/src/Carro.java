public interface Carro {
    void exibirInfo();
}
