public class PessoaJuridica extends Pessoa{
    private long cnpj;

    @Override
    public String status() {
        return "Pessoa Juridica cadastrada com sucesso!";
    }

    public long getCnpj() {
        return cnpj;
    }

    public void setCnpj(long cnpj) {
        this.cnpj = cnpj;
    }
}
