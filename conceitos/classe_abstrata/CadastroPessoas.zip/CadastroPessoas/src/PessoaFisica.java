public class PessoaFisica extends Pessoa{
    private Long cpf;

    @Override
    public String status() {
        return "Pessoa Fisica cadastrada com sucesso!";
    }

    public Long getCpf() {
        return cpf;
    }

    public void setCpf(Long cpf) {
        this.cpf = cpf;
    }
}
