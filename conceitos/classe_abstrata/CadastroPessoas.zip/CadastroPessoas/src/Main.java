public class Main {
    public static void main(String[] args) {
        PessoaFisica pessoafisica = new PessoaFisica();
        PessoaJuridica pessoajuridica = new PessoaJuridica();
        pessoafisica.setCpf(55565L);
        pessoafisica.setNome(" Joana");
        pessoajuridica.setCnpj(666666L);
        pessoajuridica.setNome(" Empreendimentos Chic");
        String stat = pessoafisica.status();
        String status = pessoajuridica.status();
        System.out.println(stat);
        System.out.println("CPF:"+pessoafisica.getCpf() + pessoafisica.getNome());
        System.out.println(status);
        System.out.println("CNPJ:"+pessoajuridica.getCnpj() + pessoajuridica.getNome());
        System.out.println();
    }
}