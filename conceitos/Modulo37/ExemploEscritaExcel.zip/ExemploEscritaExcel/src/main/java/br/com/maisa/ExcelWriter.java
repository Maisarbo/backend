package br.com.maisa;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelWriter {

    public static void main(String[] args) {
 
    	 
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("ExemploSheet");

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Nome");
            headerRow.createCell(1).setCellValue("Idade");
            headerRow.createCell(2).setCellValue("Cargo");

            Row dataRow = sheet.createRow(1);
            dataRow.createCell(0).setCellValue("John Doe");
            dataRow.createCell(1).setCellValue(30);
            dataRow.createCell(2).setCellValue("Desenvolvedor");

            try (FileOutputStream fileOut = new FileOutputStream("Test.xlsx")) {
                workbook.write(fileOut);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
