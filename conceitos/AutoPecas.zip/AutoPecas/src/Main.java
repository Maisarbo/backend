public class Main {
    public static void main(String[] args) {
        Pecas pecas = new Pecas();
        pecas.setCodigo(503009);
        pecas.setQuantidade(1);
        System.out.println("O codigo da peça é "+pecas.getCodigo());
        System.out.println("A quantidade da peça é "+pecas.getQuantidade());
        pecas.valorTotal(90.00F);
    }
}