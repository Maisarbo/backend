public class Pecas {
    private int codigo;
    private String nome;
    private int ncm;
    private String fabricante;
    private float valor;
    private float quantidade;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNcm() {
        return ncm;
    }

    public void setNcm(int ncm) {
        this.ncm = ncm;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public float getValor(float valor) {
        return this.valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public float getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(float quantidade) {
        this.quantidade = quantidade;
    }

    /**
     * Calcula o valor total, em compras que produto tem o maior que R$100.00, incide 10% desconto.
     *
     * @param valor
     */
    public void valorTotal(float valor){
      setValor(valor);
      if (valor > 100.00) {
            valor-= valor /100 * 10;
            setQuantidade(quantidade);
            float qtd = getQuantidade();
            if (qtd > 1){
                valor = qtd * valor;
            }
            else {
                System.out.println("R$"+valor);
            }
      } System.out.println("R$"+valor);
    }

        }

