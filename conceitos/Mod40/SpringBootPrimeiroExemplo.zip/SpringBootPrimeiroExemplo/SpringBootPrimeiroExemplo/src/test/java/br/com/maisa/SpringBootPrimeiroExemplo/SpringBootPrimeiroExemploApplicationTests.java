package br.com.maisa.SpringBootPrimeiroExemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPrimeiroExemploApplicationTests {

	@Test
	void contextLoads() {
	}

}
