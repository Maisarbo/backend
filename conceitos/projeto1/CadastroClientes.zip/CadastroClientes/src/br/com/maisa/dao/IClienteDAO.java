package br.com.maisa.dao;

import br.com.maisa.domain.Clientes;

import java.util.Collection;

/**
 * @author rodrigo.pires
 */
public interface IClienteDAO {

    public Boolean cadastrar(Clientes cliente);

    public void excluir(Long cpf);

    public void alterar(Clientes cliente);

    public Clientes consultar(Long cpf);

    public Collection<Clientes> buscarTodos();
}