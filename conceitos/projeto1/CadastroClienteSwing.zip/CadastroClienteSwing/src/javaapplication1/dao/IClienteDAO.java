/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package javaapplication1.dao;

/**
 *
 * @author elian
 */
import javaapplication1.domain.Clientes;

import java.util.Collection;


public interface IClienteDAO {

    public Boolean cadastrar(Clientes cliente);

    public void excluir(Long cpf);

    public void alterar(Clientes cliente);

    public Clientes consultar(Long cpf);

    public Collection<Clientes> buscarTodos();

    public void alterarCampos(Long cpf);
}