public class Main {
    public static void main(String[] args) {
        Pessoa p = new Pessoa("Maisa", "Rua ", 20);
        System.out.println(p.getNome());
    }

}