package br.com.maisa.dao;

public interface IContratoDao {
    void salvar();
    void buscar();
    void excluir();
    void ataulizar();

    //TODO
    //Fazer métodos de buscar, excluir e atualizar
}
