package br.com.maisa.service;

/**
 * @author rodrigo.pires
 */
public interface IContratoService {
    String salvar();
    String buscar();
    String excluir();
    String atualizar();

    //TODO
    //Fazer métodos de buscar, excluir e atualizar
}