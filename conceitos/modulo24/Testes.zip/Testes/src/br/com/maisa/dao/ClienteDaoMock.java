package br.com.maisa.dao;

public class ClienteDaoMock implements IClienteDao {

    @Override
    public String salvar() {
        return null;
    }

    @Override
    public String buscar() {
        return null;
    }

    @Override
    public String excluir() {
        return null;
    }

    @Override
    public String atualizar() {
        return null;
    }
}