package br.com.maisa.dao.mocks;

import br.com.maisa.dao.IContratoDao;

public class ContratoDaoMock implements IContratoDao {

    @Override
    public void salvar() {

    }

    @Override
    public void buscar() {

    }

    @Override
    public void excluir() {

    }

    @Override
    public void ataulizar() {

    }
}