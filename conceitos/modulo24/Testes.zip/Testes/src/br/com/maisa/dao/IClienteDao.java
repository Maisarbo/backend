package br.com.maisa.dao;

public interface IClienteDao {

    public String salvar();
    public String buscar();
    public String excluir();
    public String atualizar();
}
