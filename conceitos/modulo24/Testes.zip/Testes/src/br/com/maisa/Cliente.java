package br.com.maisa;

public class Cliente {
}