package test.br.com.maisa;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import test.br.com.maisa.ClienteServiceTest;
import test.br.com.maisa.ContratoServiceTest;

/**
 * @author rodrigo.pires
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({ ClienteServiceTest.class, ContratoServiceTest.class })
public class AllTests {
}