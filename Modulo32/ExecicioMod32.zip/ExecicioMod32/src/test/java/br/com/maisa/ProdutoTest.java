package br.com.maisa;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;


import br.com.maisa.dao.IProdutoDao;
import br.com.maisa.dao.ProdutoDao;
import br.com.maisa.domain.Produto;

public class ProdutoTest {
	private IProdutoDao cursoDao;
	public ProdutoTest() {
		cursoDao = new ProdutoDao();
	}

		@Test
		public void cadastrar() {
			Produto produto = new Produto();
			produto.setCodigo("A1");
			produto.setNome("Curso de Java Backend");
			cursoDao.cadastrar(produto);
			
			assertNotNull(produto);
			assertNotNull(produto.getId());
		}
	}

