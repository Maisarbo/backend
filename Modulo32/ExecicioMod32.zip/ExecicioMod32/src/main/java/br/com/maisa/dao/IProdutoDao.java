package br.com.maisa.dao;

import br.com.maisa.domain.Produto;

public interface IProdutoDao {

	public Produto cadastrar(Produto produto);
}
